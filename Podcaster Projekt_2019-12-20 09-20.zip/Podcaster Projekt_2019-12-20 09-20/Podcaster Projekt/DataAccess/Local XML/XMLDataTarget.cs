﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Podcaster_Projekt.DataAccess.Local_XML
{
    public class XMLDataTarget
    {
        public void Save(Podcaster_Projekt.Model.Podcast_Model podcast)
        {
            string folder = GetFolder();
            string file = GetName(podcast);

            PodcastSez(podcast, folder);
        }

        internal string GetFolder()
        {
            string xmlFolderName = "Xml\\";
            return xmlFolderName;
        }

        internal string GetName(Podcaster_Projekt.Model.Podcast_Model podcast)
        {
            string extension = ".xml";
            string fileName = podcast.titel + extension;
            return fileName;
        }

        private void PodcastSez(Podcaster_Projekt.Model.Podcast_Model podcast, string filename)
        {
            XmlReaderMemory serializer = new XmlReaderMemory(typeof(Podcaster_Projekt.Model.Podcast_Model));

            string foldername = filename;

            FileStream stream = new FileStream(filename, FileMode.Create, FileAccess.ReadWrite);
            serializer.Serialize(podcast);
            stream.Close();
        }
    }
}
