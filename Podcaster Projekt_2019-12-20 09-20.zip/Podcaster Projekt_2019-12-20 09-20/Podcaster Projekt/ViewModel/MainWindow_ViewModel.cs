﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Podcaster_Projekt.View;
using Podcaster_Projekt.Model;
using System.Windows;
using System.Collections.ObjectModel;

namespace Podcaster_Projekt.ViewModel
{
    public class MainWindow_ViewModel : ViewModel
    {
        private ICommand _opensearchpodcast;
        private ICommand _openrssfeedsource;
        private ICommand _opendatasource;

        public ObservableCollection<Podcast_Model> MatchedPodcasts { get; set; }
        public ObservableCollection<Provider_Model> PodcastProvider { get; set; }
        public Provider_Model SelectedProvider{ get; set; }
        public Podcast_Model SelectedPodcast { get; set; }

        //Hier wird eine Liste mit Beispielen verwendet. Wenn wir irgendwann die echte Podcast-Liste aus dem Internet zurückkriegen können wir dise ersetzen.
        public ObservableCollection<Podcast_Model> tempPodcastList { get; set; }

        public MainWindow_ViewModel()
        {
            MatchedPodcasts = new ObservableCollection<Podcast_Model>();
            PodcastProvider = new ObservableCollection<Provider_Model>();

            //Hier wird eine Liste mit Beispielen verwendet. Wenn wir irgendwann die echte Podcast-Liste aus dem Internet zurückkriegen können wir dise ersetzen.
            TempPodcastList temporaryPodcastList = new TempPodcastList();
            tempPodcastList = temporaryPodcastList.tempPodcastListe;
        }

        public ICommand OpenSearchPodcast
        {
            get
            {
                if (_opensearchpodcast == null)
                {
                    _opensearchpodcast = new RelayCommand(c => ExecuteOpenSearchPodcast_View());
                }
                return _opensearchpodcast;
            }
        }

        public ICommand OpenRssFeedSource
        {
            get
            {
                if (_openrssfeedsource == null)
                {
                    _openrssfeedsource = new RelayCommand(c => ExecuteOpenRssFeedSource_View());
                }
                return _openrssfeedsource;
            }
        }

        public ICommand OpenDataSource
        {
            get
            {
                if(_opendatasource == null)
                {
                    _opendatasource = new RelayCommand(c => ExecuteOpenDataSource_View());
                }
                return _opendatasource;
            }
        }

        private void ExecuteOpenSearchPodcast_View()
        {
            SearchPodcast_ViewModel searchPodcast_ViewModel = new SearchPodcast_ViewModel(this);
            SearchPodcast_View searchPodcast_View = new SearchPodcast_View(searchPodcast_ViewModel);
            searchPodcast_View.Show();
        }

        private void ExecuteOpenRssFeedSource_View()
        {
            RssFeedSource_ViewModel rssFeedSource_ViewModel = new RssFeedSource_ViewModel(this);
            RSS_FeedSource_View rssFeedSource_View = new RSS_FeedSource_View(rssFeedSource_ViewModel);
            rssFeedSource_View.Show();
        }

        private void ExecuteOpenDataSource_View()
        {
            DataSource_ViewModel dataSource_ViewModel = new DataSource_ViewModel(this);
            DataSource_View dataSource_View = new DataSource_View(dataSource_ViewModel);
            dataSource_View.Show();
        }
    }
}
