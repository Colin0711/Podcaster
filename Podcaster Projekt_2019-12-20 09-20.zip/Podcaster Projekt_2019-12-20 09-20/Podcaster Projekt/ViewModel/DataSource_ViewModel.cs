﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Podcaster_Projekt.View;
using Podcaster_Projekt.Model;
using System.Windows;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using System.Net;

namespace Podcaster_Projekt.ViewModel
{
    public class DataSource_ViewModel : ViewModel
    {
        private ICommand _addnewrssfeed;
        public Provider_Model provider;
        public List<Podcast_Model> podcasts;
        private readonly MainWindow_ViewModel mainWindowInstance_ViewModel;

        public ICommand AddNewRssFeed
        {
            get
            {
                if (_addnewrssfeed == null)
                {
                    _addnewrssfeed = new RelayCommand(c => ExecuteAddNewRssFeed());
                }
                return _addnewrssfeed;
            }
        }
        public DataSource_ViewModel(MainWindow_ViewModel mainWindowInstance_Viewmodel)
        {
            mainWindowInstance_ViewModel = mainWindowInstance_Viewmodel;
            podcasts = new List<Podcast_Model>();
        }
        public DataSource_ViewModel()
        {

        }

        private void ExecuteAddNewRssFeed()
        {

        }
    }
}
