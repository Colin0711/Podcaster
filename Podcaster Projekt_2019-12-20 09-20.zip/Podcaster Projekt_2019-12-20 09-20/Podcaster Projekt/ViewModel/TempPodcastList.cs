﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Podcaster_Projekt.Model;
using System.Collections.ObjectModel;

namespace Podcaster_Projekt.ViewModel
{
    public class TempPodcastList
    {
        public ObservableCollection<Podcast_Model> tempPodcastListe = new ObservableCollection<Podcast_Model>();
        public TempPodcastList()
        {
            Podcast_Model podcast1 = new Podcast_Model("Hansen1", "Pansen1", 201, "Rischtisch geiler Podcascht jungee1!");
            Podcast_Model podcast2 = new Podcast_Model("Hansen2", "Pansen2", 202, "Rischtisch geiler Podcascht jungee2!");
            Podcast_Model podcast3 = new Podcast_Model("Hansen3", "Pansen3", 203, "Rischtisch geiler Podcascht jungee3!");
            Podcast_Model podcast4 = new Podcast_Model("Hansen4", "Pansen4", 204, "Rischtisch geiler Podcascht jungee4!");

            tempPodcastListe.Add(podcast1);
            tempPodcastListe.Add(podcast2);
            tempPodcastListe.Add(podcast3);
            tempPodcastListe.Add(podcast4);
        }
    }
}
