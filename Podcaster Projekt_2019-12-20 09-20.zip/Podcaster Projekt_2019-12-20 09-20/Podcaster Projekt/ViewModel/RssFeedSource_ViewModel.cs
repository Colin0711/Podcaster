﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Podcaster_Projekt.ViewModel;
using Podcaster_Projekt.Model;
using System.Collections.ObjectModel;
using Podcaster_Projekt.View;
using System.Windows;


namespace Podcaster_Projekt.ViewModel
{
    public class RssFeedSource_ViewModel : ViewModel
    {
        private ICommand _getNewRssFeed;
        private readonly MainWindow_ViewModel mainWindowInstance_ViewModel;
        public string RssUrl { get; set; }

        public RssFeedSource_ViewModel()
        {
            RssUrl = "";
        }

        public RssFeedSource_ViewModel(MainWindow_ViewModel mainWindowInstance)
        {
            mainWindowInstance_ViewModel = mainWindowInstance;
            RssUrl = "";
        }

        public ICommand GetNewRssFeed
        {
            get
            {
                if(_getNewRssFeed == null)
                {
                    _getNewRssFeed = new RelayCommand(c => ExecuteGetNewRssFeed((Window)c));
                }
                return _getNewRssFeed;
            }
        }

        private void ExecuteGetNewRssFeed(Window rssfeedsource_View)
        {

        }
    }
}
