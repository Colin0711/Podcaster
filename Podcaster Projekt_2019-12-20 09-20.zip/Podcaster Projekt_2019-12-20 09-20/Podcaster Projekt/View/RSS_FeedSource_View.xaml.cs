﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Podcaster_Projekt.ViewModel;

namespace Podcaster_Projekt.View
{
    /// <summary>
    /// Interaktionslogik für RSS_FeedQuelle.xaml
    /// </summary>
    public partial class RSS_FeedSource_View : Window
    {
        public RSS_FeedSource_View(RssFeedSource_ViewModel rssFeedSource_ViewModel)
        {
            InitializeComponent();
            this.DataContext = rssFeedSource_ViewModel;
        }
    }
}
