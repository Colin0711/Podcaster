﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Podcaster_Projekt.ViewModel;
using Podcaster_Projekt.Model;
using Podcaster_Projekt.View;

namespace Podcaster_Projekt.View
{
    /// <summary>
    /// Interaktionslogik für PodcastSuche.xaml
    /// </summary>
    public partial class SearchPodcast_View : Window
    {
        public List<Podcast_Model> matchedpodcasts;
        public bool buttonwasclicked = false;


        public SearchPodcast_View(SearchPodcast_ViewModel searchPodcast_ViewModel)
        {
            InitializeComponent();
            this.DataContext = searchPodcast_ViewModel;
        }
    }
}
