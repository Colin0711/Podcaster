﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Podcaster_Projekt.DataAccess.Adapter;

namespace Podcaster_Projekt.DataAccess
{
    class DatabaseConnector : IAdapter
    {
        private DatabaseConnection connection;
        private IAdapter adapter;

        public DatabaseConnector()
        {
            this.adapter = new MySqlAdapter();
            this.connection = new DatabaseConnection("http://schuldb1.its-stuttgart.de", "test", "root", "iec9bei0weex7baShieg");
        }

        public DatabaseConnector(IAdapter adapter, DatabaseConnection connection)
        {
            this.adapter = adapter;
            this.connection = connection;
        }

        public void SetAdapter(IAdapter adapter)
        {
            this.adapter = adapter;
        }
        void IAdapter.connect(DatabaseConnection connection)
        {
            this.adapter.connect(this.connection);
        }
    }
}
