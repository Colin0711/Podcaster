﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Podcaster_Projekt.DataAccess.RssReader
{
    public class XmlPodcastDeserialize
    {
        // Properties
        // nestedClass zur Deserialisierung -> Attribute des Xml
        public class DeszPodcast
        {
            [XmlElement("Titel")]
            public string Title { get; set; }
            [XmlElement("Datum")]
            public string Datum { get; set; }
            public string Beschreibung { get; set; }
            [XmlElement("Beschreibung")]
            public string Autor { get; set; }
            [XmlElement("Autor")]
            public int Länge { get; set; }
            [XmlElement("Länge")]
            public string Info { get; set; }
        }

        private List<DeszPodcast> AllDeszPodcasts { get; set; }
        public List<Podcaster_Projekt.Model.Podcast_Model> Podcasts { get; set; }

        // MemoryStream mit XML
        // Podcast wird deserialisiert
        public List<Podcaster_Projekt.Model.Podcast_Model> XmlDeserializedPodcast(MemoryStream stream)
        {
            XmlReaderMemory deszReader = new XmlReaderMemory();

            SerializedShowToDataTransferObject(AllDeszPodcasts);
            return Podcasts;
        }

        /// Binding der klasseneigenen Properties an Podcast
        private void SerializedShowToDataTransferObject(List<DeszPodcast> deserializedShow)
        {
            Podcasts = new List<Podcaster_Projekt.Model.Podcast_Model>();
            foreach (DeszPodcast objekt in deserializedShow)
            {
                Podcaster_Projekt.Model.Podcast_Model newPodcast = new Podcaster_Projekt.Model.Podcast_Model
                {
                    titel = objekt.Title,
                    datum = ParseDateTimeFromStr(objekt.Datum),
                    laenge = objekt.Länge,
                    autor = objekt.Autor,
                };
                Podcasts.Add(newPodcast);
            }
        }

        // Zugriff auf ParseDateTime
        private DateTime ParseDateTimeFromStr(string date)
        {
            Podcaster_Projekt.Model.ParseDateTime dateConvert = new Podcaster_Projekt.Model.ParseDateTime();
            // Liefert Date Objekt
            return dateConvert.StringToDate(date);
        }
    }
}
