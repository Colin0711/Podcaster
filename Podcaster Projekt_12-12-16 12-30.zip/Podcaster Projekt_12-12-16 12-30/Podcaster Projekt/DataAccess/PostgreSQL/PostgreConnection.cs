﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Podcaster_Projekt.DataAccess.PostgreSQL
{
    public class PostgreConnection
    {
        public static NpgsqlConnection connection = new NpgsqlConnection();

        public NpgsqlConnection ConnectDB(string database)
        {
            // Verbindung mit Daten
            connection.ConnectionString = @"User ID = postgres; password=Vahpeiwoqu1Haex4cem6;host=localhost;database=" + database;
            // Öffne Database
            connection.Open();

            return connection;
        }

        public NpgsqlConnection openDB()
        {
            // Verbindung mit Daten
            connection.ConnectionString = @"User ID = postgres; password=Vahpeiwoqu1Haex4cem6;host=localhost;database=schuldb1";
            // Öffne Database
            connection.Open();
            return connection;
        }

        public NpgsqlConnection closeDB()
        {
            // Schließe DB
            connection.Close();
            return connection;
        }
    }
}
