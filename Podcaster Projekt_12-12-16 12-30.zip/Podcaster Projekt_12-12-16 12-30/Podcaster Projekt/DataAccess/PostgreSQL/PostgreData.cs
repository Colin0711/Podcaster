﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Podcaster_Projekt.DataAccess.PostgreSQL
{
    public class PostgreData
    {

        public static NpgsqlConnection connection = new NpgsqlConnection();

        public Boolean connectionDB(string database)
        {
            connection.ConnectionString = @"User ID = postgres; password=Vahpeiwoqu1Haex4cem6;host=localhost;database=" + database;
            bool status = true;
            connection.Open();
            return status;
        }

        public void closeConnection()
        {
            connection.Close();
        }

        public Boolean CreateDB(string db)
        {
            bool test = false;

            // Connection leer setzen
            connectionDB("");
            string sql = "CREATE DATABASE " + db + "";
            NpgsqlCommand Command = new NpgsqlCommand(sql, connection);
            closeConnection();
            return test;
        }

        // create tables
        public void CreateTable(string database)
        {
            connectionDB(database);
            string sql = @"CREATE TABLE test1 (sid serial PRIMARY KEY,
				podcastName VARCHAR(255) NOT NULL,
				description VARCHAR(2000),
				publisherName VARCHAR(100),
				category VARCHAR(100),
				language VARCHAR(30),
				lastUpDATEd DATE,
				lastBuild DATE
				);

                create table test2(downID serial PRIMARY KEY,				
				filepath VARCHAR(255)
				);";

            NpgsqlCommand Command = new NpgsqlCommand(sql, connection);
            Command.ExecuteNonQuery();
            closeConnection();
        }


        public DataTable ValDownload(string database)
        {
            string sql = "SELECT * FROM autor";

            NpgsqlCommand command = new NpgsqlCommand(sql, connection);

            connectionDB(database);

            NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(command);
            DataTable tables = new DataTable("test");

            adapter.Fill(tables);

            closeConnection();
            return tables;
        }

        public Boolean InsertValues(string db)
        {
            Boolean test = false;

            connectionDB(db);
            string sql = @"INSERT INTO podcast (sid, podcastname,description,publishername,category,language)
            VALUES (default, 'other', 'test','test', 'test','test'); ";

            NpgsqlCommand Command = new NpgsqlCommand(sql, connection);
            Command.ExecuteNonQuery();

            closeConnection();
            return test;
        }
    }
}
