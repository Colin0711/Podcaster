﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Podcaster_Projekt.DataAccess
{
    public class PodcastData
    {
        public List<Podcaster_Projekt.Model.Podcast_Model> GetAllDownloadedPodcasts()
        {
            List<Podcaster_Projekt.Model.Podcast_Model> allPodcasts = new List<Podcaster_Projekt.Model.Podcast_Model>();
            List<Podcaster_Projekt.Model.Podcast_Model> allDownloadedPodcasts = new List<Podcaster_Projekt.Model.Podcast_Model>();

            foreach (var objekt in allPodcasts)
            {
                Podcaster_Projekt.Model.Podcast_Model podcast = new Podcaster_Projekt.Model.Podcast_Model();
                allDownloadedPodcasts.Add(podcast);
            }
            return allDownloadedPodcasts;
        }
    }
}
