﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Podcaster_Projekt.DataAccess.Local_XML
{ 
    public class XMLDataQuelle
    {
        internal string GetFolderName()
        {
            string xmlFolderName = "Xml\\";
            return xmlFolderName;
        }

        private FileInfo[] FileInfo(DirectoryInfo path)
        {
            FileInfo[] files = path.GetFiles();
            return files;
        }

        private List<Podcaster_Projekt.Model.Podcast_Model> PodcastDesz(DirectoryInfo path, FileInfo[] files)
        {
            foreach (FileInfo objekt in files)
            {
                string fileName = objekt.FullName;
                XmlSerializer serializer = new XmlSerializer(typeof(Podcaster_Projekt.Model.Podcast_Model));
                FileStream fileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                Podcaster_Projekt.Model.Podcast_Model podcast = (Podcaster_Projekt.Model.Podcast_Model)serializer.Deserialize(fileStream);
            }
        }
    }
}
