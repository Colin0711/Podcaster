﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace Podcaster_Projekt.Model
{
    public class Provider_Model
    {
        public string titel { get; set; }
        public string webadresse { get; set; }
        public string beschreibung { get; set; }
        public ObservableCollection<Podcast_Model> episoden { get; set; }

        public Provider_Model()
        {
            this.episoden = new ObservableCollection<Podcast_Model>();
        }

        public Provider_Model(string titel, string webadresse, string beschreibung, ObservableCollection<Podcast_Model> episoden)
        {
            this.titel = titel;
            this.webadresse = webadresse;
            this.beschreibung = beschreibung;
            this.episoden = episoden;
        }

        public override string ToString()
        {
            return titel;
        }

    }
}
