﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniversalServer.Model
{
    public class PressureValue : ValuesBase
    {
        double _value;

        public double Value { get => _value; set => _value = value; }
    }
}
