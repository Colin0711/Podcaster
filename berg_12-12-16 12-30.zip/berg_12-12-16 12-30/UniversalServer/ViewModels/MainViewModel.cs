﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using UniversalServer.Model;
using UniversalServer.ViewModelBase;


namespace UniversalServer.ViewModels
{
    class MainViewModel : ViewModel
    {
        private ICommand _startServerCommand;
        private ICommand _showDetailsCommand;
        private IServerContract _serv;
        private string _status;
        private string _messageReceived;

        TempValue _tempMaxVal;
        TempValue _tempCurrentVal;
        TempValue _tempMinVal;

        HumidValue _humiMaxVal;
        HumidValue _humiCurrentVal;
        HumidValue _humiMinVal;

        PressureValue _pressMaxVal;
        PressureValue _pressCurrentVal;
        PressureValue _pressMinVal;

        
        
        public HumidValue FeuchteMaxValue
        {
            get
            {
                return _humiMaxVal;
            }
            set
            {
                _humiMaxVal = value;
                OnPropertyChanged("FeuchteMaxValue");
            }
        }
        public HumidValue FeuchteAktuellValue
        {
            get
            {
                return _humiCurrentVal;
            }
            set
            {
                _humiCurrentVal = value;
                OnPropertyChanged("FeuchteAktuellValue");
            }
        }
        public HumidValue FeuchteMinValue
        {
            get
            {
                return _humiMinVal;
            }
            set
            {
                _humiMinVal = value;
                OnPropertyChanged("FeuchteMinValue");
            }
        }

        public TempValue TempMaxValue
        {
            get
            {
                return _tempMaxVal;
            }
            set
            {
                _tempMaxVal = value;
                OnPropertyChanged("TempMaxValue");
            }
        }
        public TempValue TempAktuellValue
        {
            get
            {
                return _tempCurrentVal;
            }
            set
            {
                _tempCurrentVal = value;
                OnPropertyChanged("TempAktuellValue");
            }
        }
        public TempValue TempMinValue
        {
            get
            {
                return _tempMinVal;
            }

            set
            {
                _tempMinVal = value;
                OnPropertyChanged("TempMinValue");
            }
        }

        public PressureValue PressMaxVal
        {
            get => _pressMaxVal;
            set
            {
                _pressMaxVal = value;
                OnPropertyChanged("PressMaxVal");
            }
        }
        public PressureValue PressCurrentVal { get => _pressCurrentVal; set { _pressCurrentVal = value; OnPropertyChanged("PressCurrentVal"); } }
        public PressureValue PressMinVal { get => _pressMinVal; set { _pressMinVal = value; OnPropertyChanged("PressMinVal"); } }

        public string Status
        {
            get
            {
                return _status;
            }
            set
            {
                _status = value;
                OnPropertyChanged("Status");
            }
        }
        public string MessageReceived
        {
            get { return _messageReceived; }
            set
            {
                _messageReceived = value;
                try
                {
                    this.Status = String.Empty;
                    //Protokoll: Temperatur;Luftfeuchte;Luftdruck;LUX;IR
                    string temp = _messageReceived.Split(';')[0];

                    double t = Convert.ToDouble(temp);

                    TempAktuellValue = new TempValue() { DateAndTime = DateTime.Now, Value = t };

                    double luftfeuchte = Convert.ToDouble(_messageReceived.Split(';')[1]);
                    FeuchteAktuellValue = new HumidValue() { DateAndTime = DateTime.Now, Value = luftfeuchte };

                    string d = _messageReceived.Split(';')[2];
                    double druck = Convert.ToDouble(d);

                    PressCurrentVal = new PressureValue() { DateAndTime = DateTime.Now, Value = druck };

                    
                    //Max und Min-Werte feststellen und spiechern.
                    if (TempMaxValue != null)
                    {
                        if (TempAktuellValue.Value > TempMaxValue.Value)
                        {
                            TempMaxValue = TempAktuellValue;
                        }
                    }
                    else
                    { TempMaxValue = TempAktuellValue; }

                    if (TempMinValue != null)
                    {
                        if (TempAktuellValue.Value < TempMinValue.Value)
                        {
                            TempMinValue = TempAktuellValue;
                        }
                    }
                    else
                    {
                        TempMinValue = TempAktuellValue;
                    }

                    //Feuchte
                    if (FeuchteMaxValue != null)
                    {
                        if (FeuchteAktuellValue.Value > FeuchteMaxValue.Value)
                        {
                            FeuchteMaxValue = FeuchteAktuellValue;
                        }
                    }
                    else
                    {
                        FeuchteMaxValue = FeuchteAktuellValue;
                    }

                    if (FeuchteMinValue != null)
                    {
                        if (FeuchteAktuellValue.Value > FeuchteMaxValue.Value)
                        {
                            FeuchteMaxValue = FeuchteAktuellValue;
                        }

                    }
                    else
                    {
                        FeuchteMinValue = FeuchteAktuellValue;
                    }

                    //Luftdruck
                    if (PressMaxVal != null)
                    {
                        if (PressCurrentVal.Value > PressMaxVal.Value)
                        {
                            PressMaxVal = PressCurrentVal;
                        }
                    }
                    else
                    {
                        PressMaxVal = PressCurrentVal;
                    }

                    if (PressMinVal != null)
                    {
                        if (PressCurrentVal.Value < PressMinVal.Value)
                        {
                            PressMinVal = PressCurrentVal;
                        }
                    }
                    else
                    {
                        PressMinVal = PressCurrentVal;
                    }
                }
                catch (Exception ex)
                {
                    this.Status = "Fehler beim Interpretieren der Werte. " + ex.Message + Environment.NewLine +
                     _messageReceived;

                }

                OnPropertyChanged("MessageReceived");
            }
        }
        public ICommand ShowDetailsCommand
        {
            get
            {
                if (_showDetailsCommand == null)
                {
                    _showDetailsCommand = new RelayCommand(c => ExecuteShowDetailsCommand());
                }
                return _showDetailsCommand;

            }
        }
        public ICommand StartServerCommand
        {
            get
            {
                if (_startServerCommand == null)
                {
                    _startServerCommand = new RelayCommand(c => ExecuteStartServerCommand());
                }
                return _startServerCommand;

            }
        }


        private void Serv_StatusPropertyChanged1(string s)
        {
            Status = s;
        }


        private void ExecuteShowDetailsCommand()
        {
            System.Windows.MessageBox.Show(_messageReceived);
        }


        private void ExecuteStartServerCommand()
        {
            //_serv = new Server();
            _serv = new ServerMockUp();
            _serv.StatusPropertyChanged += Serv_StatusPropertyChanged1;
            _serv.MessageReceived += _serv_MessageReceived;
            _serv.Start();
            MessageReceived = "-- No Messages --";
            OnPropertyChanged("MessageReceived");
        }

        private void _serv_MessageReceived(string msg)
        {
            MessageReceived = msg;
        }
    }
}
