﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Podcaster_Projekt.DataAccess.RssReader
{
    public class XmlManageDeszerialize
    {
        // Übergabe der XML URL
        // Lade XML in MemoryStream
        //public Podcaster_Projekt.Model.Podcast_Model DeszXml(string urlXml)
        //{
        //    XmlReaderMemory xmlReader = new XmlReaderMemory();
        //    XmlDocument xmlDoc = xmlReader.CreateXMLDoc(urlXml);

        //    using (MemoryStream stream = xmlReader.LoadXmlDocInStream(xmlDoc))
        //    {
        //        xmlReader.SetStreamToZero(stream);
        //        Podcaster_Projekt.Model.Podcast_Model newPodcast = CreatePodcastNew();
        //        return newPodcast;
        //    }
        //}

        //// Erstellt ein Klassenobjekt (Podcast) 
        //private Podcaster_Projekt.Model.Podcast_Model CreatePodcastNew()
        //{
        //    Podcaster_Projekt.Model.Podcast_Model newPodcast = new Podcaster_Projekt.Model.Podcast_Model
        //    {

        //    };
        //    return newPodcast;
        //}
    }
}
