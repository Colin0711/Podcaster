﻿using Podcaster_Projekt.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Podcaster_Projekt.DataAccess
{
    public class XmlReaderMemory
    {
        private Type type;

        public XmlReaderMemory(Type type)
        {
            this.type = type;
        }

        // Lade XML-Doc mit Paramter eines Rss-Feeds
        public XmlDocument CreateXMLDoc(string urlXml)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(urlXml);
            return xmlDoc;
        }

        public MemoryStream LoadXmlDocInStream(XmlDocument xmlDoc)
        {
            // benutze MemoryStream zum auslesen der XML-Datei
            MemoryStream stream = new MemoryStream();
            xmlDoc.Save(stream);
            // Stream beginnt immer ab 0
            stream.Position = 0;
            return stream;
        }

        public MemoryStream SetStreamToZero(MemoryStream stream)
        {
            // Erneute lesen -> setze Stream auf 0 zurück
            stream.Position = 0;
            return stream;
        }

        internal void Serialize(Podcast_Model podcast)
        {
            throw new NotImplementedException();
        }
    }
}
