﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Podcaster_Projekt.ViewModel;
using Podcaster_Projekt.Model;
using System.Collections.ObjectModel;
using Podcaster_Projekt.View;
using System.Windows;

namespace Podcaster_Projekt.ViewModel
{
    public class SearchPodcast_ViewModel : ViewModel
    {
        public string SearchString { get; set; }

        private ICommand _startSearching;
        
        private readonly MainWindow_ViewModel mainWindowInstance_ViewModel;

        public List<Podcast_Model> ListOfPodcast { get; set; }

        public SearchPodcast_ViewModel(MainWindow_ViewModel mainWindowInstance)
        {
            mainWindowInstance_ViewModel = mainWindowInstance;
            TempPodcastList tempListe = new TempPodcastList();
            ListOfPodcast = tempListe.tempPodcastListe;
        }

        public ICommand StartSearching
        {
            get
            {
                if (_startSearching == null)
                {
                    _startSearching = new RelayCommand(c => ExecuteStartSeartching((Window)c));
                }
                return _startSearching;
            }
        }

        private void ExecuteStartSeartching(Window searchPodcast_View)
        {
            if (!string.IsNullOrWhiteSpace(SearchString))
            {
                mainWindowInstance_ViewModel.MatchedPodcasts.Clear();
                foreach (Podcast_Model podcast in search(SearchString))
                {
                    mainWindowInstance_ViewModel.MatchedPodcasts.Add(podcast);
                }
            }
            else
            {
                mainWindowInstance_ViewModel.MatchedPodcasts.Clear();
            }
            searchPodcast_View.Close();
        }

        public ObservableCollection<Podcast_Model> search(string text)
        {
            ObservableCollection<Podcast_Model> outputPodcastList = new ObservableCollection<Podcast_Model>();

            foreach (Podcast_Model podcast in ListOfPodcast)
            {
                if (podcast.name.Contains(text) == true | podcast.autor.Contains(text) == true | podcast.laenge.ToString().Contains(text) == true)
                {
                    outputPodcastList.Add(podcast);
                }
            }
            return outputPodcastList;
        }
    }
}
