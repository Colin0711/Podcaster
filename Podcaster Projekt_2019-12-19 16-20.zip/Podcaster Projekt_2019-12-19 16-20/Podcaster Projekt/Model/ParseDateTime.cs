﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Podcaster_Projekt.Model
{
    public class ParseDateTime
    {
        public DateTime StringToDate(string date)
        {
            string newDate = date;
            DateTime dataTime;

            if (DateTime.TryParse(newDate, out dataTime))
            {
                return dataTime;
            }
            else
            {
                return DateTime.Parse("1970-01-01 00:00:00");
            }
        }
    }
}
