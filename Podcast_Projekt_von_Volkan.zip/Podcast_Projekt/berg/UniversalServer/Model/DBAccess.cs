﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniversalServer.Model
{
    public class DBAccess
    {
        private MySqlConnection _myConnection;

        public void InitDBConnection()
        {
           _myConnection  =
                    new MySqlConnection("SERVER=10.1.1.1;" +
                    "DATABASE=temp_db;" +
                    "UID=xxx;PASSWORD=xxxx;");
        }

        public void InsertData(string d)
        {
            _myConnection.Open();

            string tempValue = d.Split(':')[1].TrimEnd('C');
            

            //Einfüge SQL-Befehl zusammenbauen.
            string myInsertQuery = @"INSERT INTO temp_values (value, date_time, raw_value)
                    Values('" + tempValue + "', '" +
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "', '" +
                    d +"')";
            MySqlCommand myCommand = new MySqlCommand(myInsertQuery);
            myCommand.Connection = _myConnection;

            myCommand.ExecuteNonQuery();


            _myConnection.Close();

        }
    }
}
