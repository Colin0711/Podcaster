﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Podcaster_Projekt.Model
{
    public class Podcast
    {
        public string name { get; set; }
        public string autor { get; set; }
        public double laenge { get; set; }
        public string beschreibung { get; set; }

        public Podcast()
        {

        }

        public Podcast(string name, string autor, double laenge, string beschreibung)
        {
            this.name = name;
            this.autor = autor;
            this.laenge = laenge;
            this.beschreibung = beschreibung;
        }

        public override string ToString()
        {
            return name;
        } 
    }
}
