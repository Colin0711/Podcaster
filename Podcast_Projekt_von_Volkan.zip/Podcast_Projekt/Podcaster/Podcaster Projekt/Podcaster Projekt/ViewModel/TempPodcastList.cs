﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Podcaster_Projekt.Model;

namespace Podcaster_Projekt.ViewModel
{
    public class TempPodcastList
    {
        public List<Podcast> tempPodcastListe = new List<Podcast>();
        public TempPodcastList()
        {
            Podcast podcast1 = new Podcast("Hansen1", "Pansen1", 201, "Rischtisch geiler Podcascht jungee1!");
            Podcast podcast2 = new Podcast("Hansen2", "Pansen2", 202, "Rischtisch geiler Podcascht jungee2!");
            Podcast podcast3 = new Podcast("Hansen3", "Pansen3", 203, "Rischtisch geiler Podcascht jungee3!");
            Podcast podcast4 = new Podcast("Hansen4", "Pansen4", 204, "Rischtisch geiler Podcascht jungee4!");

            tempPodcastListe.Add(podcast1);
            tempPodcastListe.Add(podcast2);
            tempPodcastListe.Add(podcast3);
            tempPodcastListe.Add(podcast4);
        }
    }
}
