﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Podcaster_Projekt.ViewModel;
using Podcaster_Projekt.Model;

namespace Podcaster_Projekt.ViewModel
{
    public class SearchPodcast
    {
        public List<Podcast> ListOfPodcast { get; set; }

        //public string Suchtext { get; set; }

        public SearchPodcast()
        {
            TempPodcastList tempListe = new TempPodcastList();
            ListOfPodcast = tempListe.tempPodcastListe;

            //listofpodcasts.Add(
            //    new Podcast()  {
            //        autor = "Hasi",
            //        beschreibung = "Alles über IT",
            //        laenge = 90.0,
            //        name = "Hallo It"
            //    }
            //);
        }

        public List<Podcast> search(string text)
        {
            List<Podcast> outputPodcastList = new List<Podcast>();

            foreach (Podcast podcast in ListOfPodcast)
            {
                if (podcast.name.Contains(text) == true | podcast.autor.Contains(text) == true | podcast.laenge.ToString().Contains(text) == true)
                {
                    outputPodcastList.Add(podcast);
                }
            }

            return outputPodcastList;
        }
    }
}
