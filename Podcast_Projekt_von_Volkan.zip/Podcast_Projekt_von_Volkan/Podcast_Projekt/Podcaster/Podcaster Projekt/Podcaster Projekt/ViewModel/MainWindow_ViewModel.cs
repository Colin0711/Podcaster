﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Podcaster_Projekt.View;
using Podcaster_Projekt.Model;
using System.Windows;
using System.Collections.ObjectModel;

namespace Podcaster_Projekt.ViewModel
{
    public class MainWindow_ViewModel : ViewModel
    {
        private ICommand _opensearchpodcast;

        public ObservableCollection<Podcast_Model> MatchedPodcasts { get; set; }

        public MainWindow_ViewModel()
        {
            MatchedPodcasts = new ObservableCollection<Podcast_Model>();
        }

        public ICommand OpenSearchPodcast
        {
            get
            {
                if (_opensearchpodcast == null)
                {
                    _opensearchpodcast = new RelayCommand(c => ExecuteOpenSearchPodcast_View());
                }
                return _opensearchpodcast;
            }
        }

        private void ExecuteOpenSearchPodcast_View()
        {
            SearchPodcast_ViewModel searchPodcast_ViewModel = new SearchPodcast_ViewModel(this);
            SearchPodcast_View searchPodcast_View = new SearchPodcast_View(searchPodcast_ViewModel);
            searchPodcast_View.Show();
        }

    }
}
