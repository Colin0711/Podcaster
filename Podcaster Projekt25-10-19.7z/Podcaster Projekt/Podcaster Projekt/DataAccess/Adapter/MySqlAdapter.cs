﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Podcaster_Projekt.DataAccess.Adapter;

namespace Podcaster_Projekt.DataAccess.Adapter
{
    class MySqlAdapter : IAdapter
    {
        void IAdapter.connect(DatabaseConnection connection)
        {
            string connectionString = @"Data Source="+ connection.host +";Initial Catalog=" + connection.database + ";User ID="+ connection.user +";Password=" + connection.password;
            SqlConnection cnn = new SqlConnection(connectionString);
            cnn.Open();
        }
    }
}
