﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Podcaster_Projekt.DataAccess.Adapter
{
    interface IAdapter
    {
        void connect(DatabaseConnection connection);
    }
}
