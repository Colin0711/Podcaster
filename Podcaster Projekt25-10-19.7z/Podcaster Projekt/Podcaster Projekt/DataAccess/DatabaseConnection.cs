﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Podcaster_Projekt.DataAccess
{
    class DatabaseConnection
    {
        public string host;
        public string database;
        public string user;
        public string password;

        public DatabaseConnection(string host, string database, string user, string password)
        {
            this.host = host;
            this.database = database;
            this.user = user;
            this.password = password;
        }
    }
}
